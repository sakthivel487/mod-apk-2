const admin = require('firebase-admin');
const serviceAccount = require('./serviceAccountKey.json');

async function testConnection() {
    console.log("Testing Firebase connection with serviceAccountKey.json...");
    try {
        admin.initializeApp({
            credential: admin.credential.cert(serviceAccount),
            projectId: serviceAccount.project_id
        });

        const db = admin.firestore();
        console.log("Fetching APKs...");
        const snap = await db.collection('apks').limit(1).get();
        console.log("Success! Found documents:", snap.size);
        process.exit(0);
    } catch (err) {
        console.error("Connection failed!");
        console.error(err);
        process.exit(1);
    }
}

testConnection();
