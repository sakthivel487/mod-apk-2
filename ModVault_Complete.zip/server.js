require('dotenv').config();
const express = require('express');
const session = require('express-session');
const path = require('path');
const db = require('./database');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Session
app.use(session({
  secret: 'modvault-super-secret-key-123',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false, maxAge: 1000 * 60 * 60 * 24 * 7 }
}));

// Global middleware
app.use((req, res, next) => {
  res.locals.user = req.session.user || null;
  res.locals.isAdmin = req.session.isAdmin || false;
  next();
});

// Auth Middleware
const requireAuth = (req, res, next) => {
  if (req.session.isAdmin) next();
  else res.redirect('/admin/login');
};

const requireUser = (req, res, next) => {
  if (req.session.user) next();
  else res.redirect('/');
};

// Helper function to query local DB
const queryDb = (sql, params = []) => {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => {
      if (err) reject(err);
      else resolve(rows);
    });
  });
};

const getDb = (sql, params = []) => {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => {
      if (err) reject(err);
      else resolve(row);
    });
  });
};

// =======================
// PUBLIC ROUTES
// =======================

app.get('/', async (req, res) => {
  try {
    const apks = await queryDb('SELECT * FROM apks ORDER BY downloads DESC LIMIT 10');
    const totalApks = await getDb('SELECT COUNT(*) as count FROM apks');
    const totalDownloads = await getDb('SELECT SUM(downloads) as total FROM apks');
    
    const parsedApks = apks.map(apk => ({
      ...apk,
      mod_features: JSON.parse(apk.mod_features || '[]')
    }));
    
    res.render('index', { 
      apks: parsedApks, 
      currentRoute: 'home',
      stats: {
        apks: totalApks ? totalApks.count : 0,
        downloads: (totalDownloads && totalDownloads.total) ? totalDownloads.total : 0
      }
    });
  } catch (err) {
    console.error(err);
    res.status(500).send("Server Error");
  }
});

app.get('/games', async (req, res) => {
  try {
    const apks = await queryDb("SELECT * FROM apks WHERE category = 'games' ORDER BY upload_date DESC");
    res.render('games', { apks, currentRoute: 'games' });
  } catch (err) {
    res.status(500).send("Server Error");
  }
});

app.get('/apps', async (req, res) => {
  try {
    const apks = await queryDb("SELECT * FROM apks WHERE category = 'apps' ORDER BY upload_date DESC");
    res.render('apps', { apks, currentRoute: 'apps' });
  } catch (err) {
    res.status(500).send("Server Error");
  }
});

app.get('/app/:slug', async (req, res) => {
  try {
    const apk = await getDb("SELECT * FROM apks WHERE slug = ?", [req.params.slug]);
    if (!apk) return res.status(404).send("App not found");
    apk.mod_features = JSON.parse(apk.mod_features || '[]');
    apk.how_to_install = JSON.parse(apk.how_to_install || '[]');
    const similar = await queryDb("SELECT * FROM apks WHERE category = ? AND id != ? LIMIT 3", [apk.category, apk.id]);
    res.render('app', { apk, similar, currentRoute: 'app' });
  } catch (err) {
    res.status(500).send("Server Error");
  }
});

app.get('/search', async (req, res) => {
  const q = req.query.q || '';
  try {
    const apks = await queryDb("SELECT * FROM apks WHERE name LIKE ?", [`%${q}%`]);
    res.render('search', { apks, query: q, currentRoute: 'search' });
  } catch (err) {
    res.status(500).send("Server Error");
  }
});

app.get('/categories', (req, res) => res.render('categories', { currentRoute: 'categories' }));
app.get('/latest', async (req, res) => {
  try {
    const apks = await queryDb("SELECT * FROM apks ORDER BY upload_date DESC");
    res.render('latest', { apks, currentRoute: 'latest' });
  } catch(err) {
    res.status(500).send("Server Error");
  }
});
app.get('/download/:slug', async (req, res) => {
  try {
    const apk = await getDb("SELECT * FROM apks WHERE slug = ?", [req.params.slug]);
    if (!apk) return res.status(404).send("App not found");
    res.render('download', { apk, currentRoute: 'download' });
  } catch(err) {
    res.status(500).send("Server Error");
  }
});

// Legal pages
app.get('/contact', (req, res) => res.render('contact', { currentRoute: 'contact' }));
app.get('/faq', (req, res) => res.render('faq', { currentRoute: 'faq' }));
app.get('/terms', (req, res) => res.render('terms', { currentRoute: 'terms' }));
app.get('/privacy', (req, res) => res.render('privacy', { currentRoute: 'privacy' }));
app.get('/disclaimer', (req, res) => res.render('disclaimer', { currentRoute: 'disclaimer' }));
app.get('/dmca', (req, res) => res.render('dmca', { currentRoute: 'dmca' }));
app.get('/cookies', (req, res) => res.render('cookies', { currentRoute: 'cookies' }));

// =======================
// AUTH ROUTES
// =======================

app.post('/api/firebase-auth', async (req, res) => {
  const { uid, email, name, role } = req.body;
  if (!email) return res.status(400).json({ error: 'Missing email' });

  try {
    let user = await getDb('SELECT * FROM users WHERE email = ?', [email]);
    if (!user) {
      const username = email.split('@')[0] + '_' + Math.random().toString(36).slice(-4);
      const joinDate = new Date().toISOString();
      await new Promise((resolve, reject) => {
        db.run(
          'INSERT INTO users (name, username, email, password, role, join_date) VALUES (?, ?, ?, ?, ?, ?)',
          [name, username, email, 'firebase_auth', role || 'user', joinDate],
          function(err) {
            if (err) reject(err);
            else resolve(this.lastID);
          }
        );
      }).then(id => {
        user = { id, name, username, email, role: role || 'user' };
      });
    }
    req.session.user = user;
    if (user.role === 'admin') req.session.isAdmin = true;
    res.json({ success: true, user });
  } catch (err) {
    res.status(500).json({ error: 'Auth error' });
  }
});

app.post('/api/logout', (req, res) => {
  req.session.destroy();
  res.json({ success: true });
});

// =======================
// USER PROFILE ROUTES
// =======================

app.get('/profile', requireUser, async (req, res) => {
  try {
    const stats = await getDb('SELECT COUNT(*) as count FROM user_downloads WHERE user_id = ?', [req.session.user.id]);
    const downloads = await queryDb(`
      SELECT apks.*, user_downloads.download_date 
      FROM user_downloads 
      JOIN apks ON user_downloads.apk_id = apks.id 
      WHERE user_downloads.user_id = ? 
      ORDER BY user_downloads.download_date DESC LIMIT 4
    `, [req.session.user.id]);
    res.render('profile', { currentRoute: 'profile', downloads, totalDownloads: stats ? stats.count : 0 });
  } catch (err) {
    res.status(500).send('Server Error');
  }
});

app.get('/downloads', requireUser, async (req, res) => {
  try {
    const downloads = await queryDb(`
      SELECT apks.*, user_downloads.download_date 
      FROM user_downloads 
      JOIN apks ON user_downloads.apk_id = apks.id 
      WHERE user_downloads.user_id = ? 
      ORDER BY user_downloads.download_date DESC
    `, [req.session.user.id]);
    res.render('downloads', { currentRoute: 'downloads', downloads });
  } catch (err) {
    res.status(500).send('Server Error');
  }
});

// =======================
// ADMIN ROUTES
// =======================

app.get('/admin/login', (req, res) => {
  if (req.session.isAdmin) return res.redirect('/admin');
  res.render('admin_login', { error: null });
});

app.post('/admin/login', (req, res) => {
  const { password } = req.body;
  if (password === 'admin123') {
    req.session.isAdmin = true;
    res.redirect('/admin');
  } else {
    res.render('admin_login', { error: 'Invalid password' });
  }
});

app.get('/admin/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/admin/login');
});

app.get('/admin', requireAuth, async (req, res) => {
  try {
    const apks = await queryDb('SELECT * FROM apks ORDER BY upload_date DESC');
    const totalDownloads = apks.reduce((sum, apk) => sum + (apk.downloads || 0), 0);
    const totalGames = apks.filter(a => a.category === 'games').length;
    const totalApps = apks.filter(a => a.category === 'apps').length;
    res.render('admin', { 
      apks, 
      stats: { total: apks.length, downloads: totalDownloads, games: totalGames, apps: totalApps }
    });
  } catch (err) {
    res.status(500).send("Server Error");
  }
});

app.post('/admin/api/apk', requireAuth, (req, res) => {
  const { name, version, category, sub_category, size, android_required, rating, icon, download_url, mod_features, description, how_to_install } = req.body;
  const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-') + '-mod-apk-' + Date.now().toString().slice(-4);
  const featuresJson = JSON.stringify(mod_features ? mod_features.split('\n').filter(Boolean) : []);
  const installJson = JSON.stringify(how_to_install ? how_to_install.split('\n').filter(Boolean) : []);
  db.run(`INSERT INTO apks (name, slug, version, category, sub_category, size, android_required, rating, icon, icon_bg, download_url, mod_features, description, how_to_install, upload_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, 
    [name, slug, version, category, sub_category, size, android_required, parseFloat(rating) || 4.5, icon || '📱', 'linear-gradient(135deg, #6c63ff, #a78bfa)', download_url, featuresJson, description, installJson, new Date().toISOString().split('T')[0]], 
    function(err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ success: true, id: this.lastID, slug });
    }
  );
});

app.delete('/admin/api/apk/:id', requireAuth, (req, res) => {
  db.run('DELETE FROM apks WHERE id = ?', [req.params.id], function(err) {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ success: true });
  });
});

app.listen(PORT, () => {
  console.log(`Local server running on http://localhost:${PORT}`);
});
